**To enable a VPC for ClassicLink**

This example enables vpc-8888888 for ClassicLink.

Command::

  aws ec2 enable-vpc-classic-link --vpc-id vpc-88888888

Output::

  {
    "Return": true
  }